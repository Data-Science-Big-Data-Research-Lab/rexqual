package hp;

import java.io.File;
import java.io.FileFilter;

public class Test {

	static String ext = "csv";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String originalPath = (args.length > 0) ? args[0] :  "./csv/";
		String out = (args.length > 1) ? args[1] : "./datasets"; 

		String outputFileName = "";

		File dres = new File(out);
		dres.mkdir();

		File directorios = new File(originalPath);

		FileFilter fileFilter = new FileFilter() {
			public boolean accept(File file) {
				return file.isFile();
			}
		};

		File[] dirs = directorios.listFiles(fileFilter);

		if (dirs != null) {
			for (int i = 0; i < dirs.length; i = i + 1) {
				String filename = dirs[i].getName();
				String file = originalPath + filename;
				System.out.print(filename + "\n");
				String name = filename.replaceAll(".csv", "");
				outputFileName = convert(file, out+"/" + name);

				System.out.println("Salida en: " + outputFileName);
			}
		}

	}


	public static String convert(String inputFile, String outputFile) {

		System.out.println("Input " + inputFile + " Output " + outputFile);
		String separatorValue = "";
		String nullValueValue = "";

		String pathnameOutput = "";

		// CSV file
		// --------
		if (ext.equals("csv")) {

			File fileInput = new File(inputFile);

			if (!fileInput.exists()) {
				System.out.println("Input file doesn't exists");
				return null;
			}

			File fileOutput = new File(outputFile);

			if (!fileOutput.exists()) {
				fileOutput.mkdir();
			}

			separatorValue = ",";

			nullValueValue = "";

			boolean processHeader;

			processHeader = true;

			String pathnameInput = inputFile;
			pathnameOutput = outputFile;
			String nullValue = nullValueValue;
			String separator = separatorValue;

			File fileInput1 = new File(pathnameInput);

			// Obtenemos la ruta del fichero de salida
			String filenameOutput = fileInput1.getName();

			// le quito la extension al nombre del fichero
			filenameOutput = filenameOutput.substring(0, filenameOutput.lastIndexOf('.'));


			String separatorFile = File.separator;

			if (!pathnameOutput.endsWith(separatorFile)) {
				pathnameOutput = pathnameOutput.concat(separatorFile);
			}

			File fileOutput1 = new File(pathnameOutput);
			fileOutput1.mkdirs();

			pathnameOutput = pathnameOutput.concat(filenameOutput);
			pathnameOutput = pathnameOutput.concat(".dat");

			try {

				CsvToKeel csv2keel = new CsvToKeel(nullValue, separator);
				csv2keel.setProcessHeader(processHeader);
				csv2keel.Start(pathnameInput, pathnameOutput);

			} catch (Exception ex) {
				System.out.println("Error importing data file:\nThe file does not appear to be in CSV format");
				return null;
			}

		} 

		return pathnameOutput;

	}
}
